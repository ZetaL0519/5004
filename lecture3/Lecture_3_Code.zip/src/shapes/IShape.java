package shapes;

public interface IShape {
  double getArea();
  double getPerimeter();
}
