package Model;

/**
 * This is an interface for
 */
public interface IShapeController {

  void ShapeGame(ShapeModel m);
}
