package shapes;

public interface IShape {
  double getPerimeter();
  double getArea();
}
