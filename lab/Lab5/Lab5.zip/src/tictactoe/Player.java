package tictactoe;

/**
 * Enum type Player that contains X and O.
 */
public enum Player {
  X, O;
}
