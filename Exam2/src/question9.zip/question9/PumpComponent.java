package question9;

public class PumpComponent implements IPumpComponent{
  @Override
  public void accept(IPumpComponentVisitor repairDrone) {

  }
}
