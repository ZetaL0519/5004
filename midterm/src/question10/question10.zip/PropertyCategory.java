package question10;

public enum PropertyCategory {
  BUDGET, STANDARD, LUXURY;
}
