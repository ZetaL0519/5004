package View;

/**
 * This is the IView interface.
 */
public interface IView {

  /**
   * Display view.
   */
  void display();
}
