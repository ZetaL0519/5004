/**
 * Created by ashesh on 2/5/2016.
 */
public interface IModel {
  void setString(String i);

  String getString();
}
